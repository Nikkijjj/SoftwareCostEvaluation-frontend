
### 文档如下

#### 路由的添加（待完善）
``` javascript
/**
 * 为路由配置meta相当于为该路由配置了基本信息，配置的属性如下
 * title 用作标签显示字样的字段
 * hasTag 可以生成标签
 * isCache 该标签页面是否缓存
 * hidden 该标签页面是否在左边目录上显示
 * isLink 表示直接跳转新页面
 * iconName 菜单icon图标
 * fixed 标签是否固定
 * layoutName layout的名称，用作分组
 * redirectName 重定向的目标
 * path 路由地址，唯一键
 * fullPath
 * showTagIcon 标签显示的时候是否显示图标
 * content 菜单显示的详情
 * number 菜单显示的数字
 */
{
    path: 'new-tag-page/:sign',
    component: () => import('@/views/system/newTagPage/index.vue'),
    name: 'new-tag-page',
    meta: { 
        layoutName: 'main',
        redirectName: 'main-redirect',
        title: '新标签',
        hasTag: true,
    },
}
```

#### 菜单的添加（待完善）
``` javascript
/** 
 * path和name为唯一属性，两者都可选填，标签页的配置会使用此配置（path优先）
 * 用作权限验证以及独立配置路由信息，优先级高于路由的meta配置
 * 需要配置的属性与路由的meta的属性一致
 *  */
{
    name:"main-index",
    title:'首页',
    content:'(有缓存，并且标签页固定)',
    isCache:true,
    fixed:true,
    iconName:"all-fill",
    hasTag: true,
}
```
