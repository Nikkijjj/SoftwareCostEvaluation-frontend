<template>
    <DefinScrollbar height="100%" :showUpBt="true">
        <div class="page-container main-view">
            <div class="container">
                <h3>算道-软件造价评估系统</h3>
              
                <div class="echart-container">
                    <div class="top-container">
                        <div class="left">
                            <EchartContainer ref="EchartContainerRef"></EchartContainer>
                        </div>
                        <div class="right">
                            <EchartContainer ref="EchartContainerRef_1"></EchartContainer>
                        </div>
                    </div>
                    <div class="bottom-container">
                        <EchartContainer ref="EchartContainerRef_2"></EchartContainer>
                    </div>
                </div>
            </div>
        </div>
    </DefinScrollbar>
</template>

<script>
import {
    defineComponent,
    onMounted,
    ref,
    reactive,
} from 'vue';
import { useRouter } from 'vue-router';
import SvgIcon from '@/components/svgIcon/index.vue';
import EchartContainer from '@/components/echartContainer.vue';
import DefinScrollbar from '@/components/definScrollbar.vue';
import * as echarts from 'echarts';

export default defineComponent({
    components: {
        SvgIcon,
        EchartContainer,
        DefinScrollbar,
    },
    setup() {
        const router = useRouter();
        const EchartContainerRef = ref(); //组件实例
        const EchartContainerRef_1 = ref(); //组件实例
        const EchartContainerRef_2 = ref(); //组件实例
        const dataContainer = reactive({
            loading: false,
        });

        onMounted(() => {
            /** 初始化图表 */
            // 软件开发阶段成本分布图
            EchartContainerRef.value.initData({
                backgroundColor: '',
                title: {
                    text: '软件开发阶段成本分析',
                    x: 'left',
                    textStyle: { fontSize: '15', color: '#000' },
                },
                tooltip: { trigger: 'axis' },
                legend: { data: ['需求分析', '设计', '开发', '测试', '部署'], right: 0 },
                grid: { top: 70, right: 80, bottom: 30, left: 80 },
                xAxis: [
                    {
                        type: 'category',
                        data: ['阶段1', '阶段2', '阶段3', '阶段4', '阶段5'],
                        boundaryGap: true,
                        axisTick: { show: false },
                    },
                ],
                yAxis: [
                    {
                        name: '费用 (万元)',
                        nameLocation: 'middle',
                        nameTextStyle: { padding: [3, 4, 50, 6] },
                        splitLine: { show: true, lineStyle: { type: 'dashed', color: '#f5f5f5' } },
                        axisLine: { show: false },
                        axisTick: { show: false },
                        axisLabel: { color: '#000', formatter: '{value} ' },
                    },
                ],
                series: [
                    {
                        name: '需求分析',
                        type: 'line',
                        smooth: true,
                        showSymbol: true,
                        symbol: 'path://M150 0 L80 175 L250 75 L50 75 L220 175 Z',
                        symbolSize: 12,
                        yAxisIndex: 0,
                        areaStyle: {
                            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                                { offset: 0, color: 'rgba(250,180,101,0.3)' },
                                { offset: 1, color: 'rgba(250,180,101,0)' },
                            ]),
                            shadowColor: 'rgba(250,180,101,0.2)',
                            shadowBlur: 20,
                        },
                        itemStyle: { color: '#FF8000' },
                        data: [12, 20, 15, 30, 25],
                    },
                    {
                        name: '设计',
                        type: 'line',
                        smooth: true,
                        showSymbol: true,
                        symbol: 'emptyCircle',
                        symbolSize: 12,
                        yAxisIndex: 0,
                        areaStyle: {
                            color: new echarts.graphic.LinearGradient(
                                0,
                                0,
                                0,
                                1,
                                [
                                    { offset: 0, color: 'rgba(199, 237, 250,0.5)' },
                                    { offset: 1, color: 'rgba(199, 237, 250,0.2)' },
                                ],
                                false,
                            ),
                        },
                        itemStyle: {
                            color: '#3bbc86',
                        },
                        data: [8, 12, 18, 22, 15],
                    },
                    {
                        name: '开发',
                        type: 'line',
                        smooth: true,
                        showSymbol: true,
                        symbol: 'path://M150 0 L80 175 L250 75 L50 75 L220 175 Z',
                        symbolSize: 12,
                        yAxisIndex: 0,
                        areaStyle: {
                            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                                { offset: 0, color: 'rgba(108,80,243,0.3)' },
                                { offset: 1, color: 'rgba(108,80,243,0)' },
                            ]),
                            shadowColor: 'rgba(108,80,243,0.2)',
                            shadowBlur: 20,
                        },
                        itemStyle: { color: '#6C50F3' },
                        data: [15, 25, 30, 40, 35],
                    },
                ],
            });

            // 团队分配资源饼图
            EchartContainerRef_1.value.initData({
                tooltip: {
                    trigger: 'item',
                },
                legend: {
                    top: '5%',
                    left: 'center',
                },
                series: [
                    {
                        name: '团队资源分配',
                        type: 'pie',
                        radius: ['40%', '70%'],
                        avoidLabelOverlap: false,
                        itemStyle: {
                            borderRadius: 10,
                            borderColor: '#fff',
                            borderWidth: 2,
                        },
                        label: {
                            show: false,
                            position: 'center',
                        },
                        emphasis: {
                            label: {
                                show: true,
                                fontSize: 40,
                                fontWeight: 'bold',
                            },
                        },
                        labelLine: {
                            show: false,
                        },
                        data: [
                            { value: 1048, name: '开发团队' },
                            { value: 735, name: '设计团队' },
                            { value: 580, name: '测试团队' },
                            { value: 484, name: '运维团队' },
                            { value: 300, name: '项目管理团队' },
                        ],
                    },
                ],
            });

            // 预算分配与花费对比
            EchartContainerRef_2.value.initData({
                backgroundColor: '',
                title: {
                    text: '软件开发预算与实际花费对比',
                    x: 'left',
                    textStyle: { fontSize: '15', color: '#000000' },
                },
                grid: { top: 70, right: 20, bottom: 30, left: 30 },
                tooltip: { trigger: 'axis' },
                legend: { data: ['预算金额', '实际花费'], right: 0 },
                xAxis: {
                    data: [
                        '1月',
                        '2月',
                        '3月',
                        '4月',
                        '5月',
                        '6月',
                        '7月',
                        '8月',
                        '9月',
                        '10月',
                        '11月',
                        '12月',
                    ],
                },
                yAxis: [
                    {
                        type: 'value',
                        name: '金额 (万元)',
                        splitLine: { show: true, lineStyle: { type: 'dashed', color: '#f5f5f5' } },
                    },
                ],
                series: [
                    {
                        name: '预算金额',
                        type: 'line',
                        symbolSize: 6,
                        symbol: 'circle',
                        smooth: true,
                        data: [200, 180, 190, 230, 210, 220, 230, 250, 240, 260, 280, 300],
                        lineStyle: { color: '#fe9a8b' },
                        itemStyle: { color: '#fe9a8b', borderColor: '#fe9a8b' },
                        areaStyle: {
                            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                                { offset: 0, color: '#fe9a8bb3' },
                                { offset: 1, color: '#fe9a8b03' },
                            ]),
                        },
                    },
                    {
                        name: '实际花费',
                        type: 'line',
                        symbolSize: 6,
                        symbol: 'circle',
                        smooth: true,
                        data: [150, 170, 180, 200, 190, 210, 220, 240, 250, 260, 270, 290],
                        lineStyle: { color: '#9E87FF' },
                        itemStyle: { color: '#9E87FF', borderColor: '#9E87FF' },
                        areaStyle: {
                            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                                { offset: 0, color: '#9E87FFb3' },
                                { offset: 1, color: '#9E87FF03' },
                            ]),
                        },
                    },
                ],
            });
        });

        return {
            dataContainer,
            EchartContainerRef,
            EchartContainerRef_1,
            EchartContainerRef_2,
        };
    },
});
</script>

<style lang="scss" scoped>
.main-view {
    display: flex;
    flex-direction: column;
    width: 100%;
    .container {
        background-color: white;
        width: 100%;
        min-height: 800px;
        border-radius: 5px;
        padding: 15px;
        box-sizing: border-box;
        > * {
            margin: 0 0 30px 0;
            &:last-child {
                margin: 0;
            }
        }
        > .echart-container {
            width: 100%;
            > .top-container {
                display: flex;
                flex-direction: row;
                height: 300px;
                > .left,
                > .right {
                    width: 0;
                    flex: 1 1 0;
                }
                > .left {
                    flex: 2 1 0;
                    margin-right: 60px;
                }
            }
            > .bottom-container {
                width: 100%;
                height: 400px;
                margin-top: 30px;
            }
        }
    }
}
</style>
