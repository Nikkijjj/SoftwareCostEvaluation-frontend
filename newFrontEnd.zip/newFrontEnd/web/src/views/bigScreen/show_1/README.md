大屏展示主页面

只是一个例子。
借鉴 https://github.com/zouzhibin/zb-admin
感谢作者