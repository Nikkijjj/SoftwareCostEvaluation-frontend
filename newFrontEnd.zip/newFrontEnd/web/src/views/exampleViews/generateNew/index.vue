<template>
  <DefinScrollbar height="100%" :showUpBt="true">
    <div class="page-container">
      <!-- 全局加载指示器 -->
      <div v-if="isLoading" class="loading-overlay">
        <div class="spinner"></div>
      </div>

      <!-- 第一行：标题和按钮 -->
      <div class="header-container">
        <div class="title-container">
          <img src="./icon.png" alt="Icon" class="title-icon" />
          <p class="title">生成项目评估报告</p>
        </div>
         <!-- 新增的下拉选择框 -->
         <el-select v-model="selectedProjectId" placeholder="选择项目" class="project-select" @change="onProjectChange">
          <el-option
            v-for="project in projects"
            :key="project.project_id"
            :label="project.project_name"
            :value="project.project_id"
          />
        </el-select>
        <div class="button-container">
        <el-button type="primary" class="generate-btn" @click="handleClick">生成文档</el-button>
        <el-button type="primary" class="refresh-btn" @click="updateDocumentAfterEdit">刷新文档</el-button>
        <el-button type="success" class="upload-btn" @click="handleUploadNewFile">上传新文件</el-button>
        <el-button type="primary" class="submit-btn" @click="handleSubmit">提交</el-button>
        <input type="file" @change="handleFileChange" accept=".doc,.docx" class="file-input" />
        <span v-if="uploadedFileName">
          <a :href="uploadedFileUrl" download class="uploaded-file-name">{{ uploadedFileName }}</a>
        </span>
      </div>

      </div>
      <!-- 预览和注意事项部分 -->
      <div class="preview-and-notice-container">
        <div class="preview-container" :style="{ height: 630 + 'px' }">
          <div v-if="!isDocumentGenerated" class="preview-placeholder">
            <p>请点击“生成文档”按钮<br />进行软件项目评估文档生成</p>
            <p>右下角可以下载/打印成PDF<br />并可以登录MicrosoftOffice进行编辑</p>
            <p>点击上传文档上传新修改的文档</p>
          </div>
          <iframe 
            v-if="isDocumentGenerated && fileUrl" 
            :src="officeEmbedUrl" 
            class="doc-preview" 
            frameborder="0" 
            allowfullscreen
            @load="onPreviewLoad">
          </iframe>
        </div>

        <div class="notice-container" :style="{ height: previewHeight + 'px' }">
          <h3>注意事项</h3>
          <ul>
            <li>请确保上传的文档格式为 DOCX。</li>
            <li>文档生成后，您可以预览并下载。</li>
            <li>刷新文档时会上传更新后的内容。</li>
            <li class="highlight">刷新整个网页，需要重新生成，请注意。</li>
          </ul>
            <!-- 新增审核状态部分 -->
            <div class="audit-status-container">
              <h4>审核状态</h4>
              <div v-if="auditStatus === 0" class="audit-status failed">
                <span class="status-text">未通过</span>
              </div>
              <div v-if="auditStatus === 1" class="audit-status passed">
                <span class="status-text">已通过</span>
              </div>
              <div v-if="auditStatus === null" class="audit-status loading">
                <span class="status-text">加载中...</span>
              </div>
            </div>
            <!-- 如果审核状态不是已通过，显示审核意见部分 -->
            <div v-if="auditStatus !== 1" class="audit-opinion-container">
              <h4>审核意见</h4>
              <div class="audit-opinion-wrapper">
                <p v-if="auditOpinion" class="audit-opinion-text">{{ auditOpinion }}</p>
                <p v-else>暂无审核意见</p>
                <el-button 
                  type="primary" 
                  @click="fetchAuditOpinion(1)" 
                  :loading="isLoading" 
                  :disabled="auditStatus === null"
                  class="refresh-btn">
                  刷新审核意见
                </el-button>
              </div>
            </div>
        </div>
      </div>
    </div>
  </DefinScrollbar>
</template>

<script>
import VueOfficeDocx from '@vue-office/docx';
import '@vue-office/docx/lib/index.css';
import { defineComponent, ref } from 'vue';
import { onMounted } from 'vue';
import axios from 'axios';
import OSS from 'ali-oss';
import { createDoc } from './generateDocx/index';
import { ElMessage } from 'element-plus';
axios.defaults.withCredentials = true;
export default defineComponent({
  components: {
    VueOfficeDocx
  },
  setup() {
    const fileUrl = ref('');  // 存储生成的文件URL
    const officeEmbedUrl = ref('');  // 存储 Office Online 编辑器的嵌入链接
    const previewHeight = ref(600);  // 预览框和注意事项框的高度
    const isDocumentGenerated = ref(false);  // 标志变量，判断文档是否生成
    const uploadedFileUrl = ref(''); // 新上传文件的URL
    const uploadedFileName = ref(''); // 用于存储上传文件的名称
    const isLoading = ref(false); // 新增加载状态
    const auditStatus = ref(null);  // 新增的审核状态变量
    const auditOpinion = ref('');  // 审核意见
    const projects = ref([]);
    const selectedProjectId = ref(null);  // Define the selectedProjectId variable
    const projectData = ref(null);  // 存储选中的项目的数据
    const projectModuleData = ref(null);  // 存储选中的项目的数据
     // 获取项目列表
     const fetchProjects = async () => {
      try {
        const response = await axios.get('http://localhost:9000/project/selectAllProjects');  // 假设后端接口是这个
        if (response.data.isOK) {
          console.log("项目列表", response.data.projects);  // 确保数据正确
          projects.value = response.data.projects;  // 假设返回的数据结构是 { isOk: true, projects: [...] }
        } else {
          console.error('获取项目信息失败');
        }
      } catch (error) {
        console.error('请求项目信息失败:', error);
      }
    };
    // 获取项目的详细信息
    const fetchProjectDetails = async (projectId) => {
      try {
        const response = await axios.get('http://localhost:9000/project/getall', {
          params: { projectId }
        });
        if (response.data.isOk) {
          projectData.value = response.data.project;  // 保存项目数据
        } else {
          console.error('获取项目详情失败');
        }
      } catch (error) {
        console.error('请求项目详情失败:', error);
      }
    };
    const fetchProjectModules = async (projectId) => {
      try {
        const response = await axios.get('http://localhost:9000/structure/getModule', {
          params: { projectId }
        });
        if (response.data.isOk) {
          projectModuleData.value = response.data.projectModules;  // 保存项目模块数据
          console.log("项目模块数据为", projectModuleData.value);  // 这里打印出来可以检查数据
        } else {
          console.error('获取项目模块数据失败');
        }
      } catch (error) {
        console.error('请求项目模块数据失败:', error);
      }
    };


    // 处理项目选择变化
    const onProjectChange = (newProjectId) => {
      console.log('选择的项目ID:', newProjectId);
      selectedProjectId.value = newProjectId; // 更新选中的项目 ID
      // 根据选择的项目ID进行相关操作，比如获取该项目的状态和审核意见
      fetchAuditStatusAndOpinion(newProjectId); // 根据选中的项目ID获取审核状态
      fetchProjectDetails(newProjectId); // 获取选中的项目的详细信息
      fetchProjectModules(newProjectId);
    };

   // 获取审核状态和审核意见
    async function fetchAuditStatusAndOpinion(projectId) {
      try {
        const response = await axios.get('http://localhost:9000/project/getStatus', {
          params: { projectId }
        });
        if (response.data.isOk) {
          auditStatus.value = response.data.status === '1' ? 1 : (response.data.status === '0' ? 0 : null);
          fetchAuditOpinion(projectId);  // 获取审核意见
        } else {
          auditStatus.value = null;
          auditOpinion.value = '';
        }
      } catch (error) {
        console.error('获取审核状态和意见失败:', error);
        auditStatus.value = null;
        auditOpinion.value = '';
      }
    }

    async function fetchAuditOpinion(projectId) {
      isLoading.value = true;
      try {
        console.log('Fetching audit opinion for projectId:', projectId);
        const response = await axios.get('http://localhost:9000/project/getSuggest', {
          params: { projectId }
        });
        console.log('Response from getSuggest:', response.data);

        if (response.data.isOk) {
          auditOpinion.value = response.data.suggest || '暂无审核意见';  // 更新审核意见
        } else {
          auditOpinion.value = '暂无审核意见';
          ElMessage.error('未找到对应的审核意见');
        }
      } catch (error) {
        console.error('获取审核意见失败:', error);
        auditOpinion.value = '获取审核意见失败';
        ElMessage.error('获取审核意见失败');
      } finally {
        isLoading.value = false;
      }
    }


    // 页面加载时，获取审核状态和审核意见
    onMounted(() => {
      fetchProjects();  // 获取项目列表
    });

    // 获取 OSS 签名
    async function getOssSignature() {
      try {
        const response = await axios.get('http://localhost:9000/getOssSignature');
        return response.data.data;
      } catch (error) {
        console.error('获取签名失败:', error);
        throw error;
      }
    }

    // 上传文件到阿里云 OSS
    async function uploadFileToOss(blob, version) {
      const { accessKeyId, accessKeySecret, securityToken, bucketName, stsEndpoint } = await getOssSignature();
      const client = new OSS({
        region: 'oss-cn-beijing', 
        accessKeyId,
        accessKeySecret,
        stsToken: securityToken,
        bucket: bucketName,
        endpoint: stsEndpoint,
      });

      const filename = `generated/doc-v${version}.docx`;
      try {
        const result = await client.put(filename, blob, {
          headers: {
            'x-oss-object-acl': 'private'
          }
        });
        console.log('文件上传成功', result);
        return result.name;
      } catch (error) {
        console.error('文件上传失败', error);
        return null;
      }
    }

    // 获取文件的签名 URL
    async function getSignedUrl(filename) {
      const { accessKeyId, accessKeySecret, securityToken, bucketName } = await getOssSignature();
      const client = new OSS({
        region: 'oss-cn-beijing',
        accessKeyId,
        accessKeySecret,
        stsToken: securityToken,
        bucket: bucketName,
      });

      let url = await client.signatureUrl(filename, {
        expires: 60 * 60 * 24 * 30  // 30 天有效期
      });
      url = url.replace(/^http:\/\//i, 'https://');
      return url;
    }
    // 动态生成 form 对象
    const generateForm = (projectData, projectModuleData) => {
      if (!projectData) return {}; // 如果没有项目数据，直接返回空对象

      const form = {};

      // 将 projectData 添加到 form 中
      for (const key in projectData) {
        if (projectData.hasOwnProperty(key)) {
          form[key] = projectData[key];
        }
      }

      // 确保 projectModuleData 是数组，避免 undefined
      if (Array.isArray(projectModuleData) && projectModuleData.length > 0) {
        form.modules = projectModuleData.map(module => ({
          module_name: module.module_name,
          module_desc: module.module_desc,
        }));
      } else {
        form.modules = []; // 如果没有模块数据，确保 `form.modules` 是空数组
      }

      console.log('生成的Moduleform 数据:', form.modules); // 打印模块数据，查看其结构
      return form;
    };


     // 生成文档
     const handleClick = async () => {
      isLoading.value = true; // 开始加载

      if (!projectData.value) {
        ElMessage.error('请先选择一个项目');
        isLoading.value = false;
        return;
      }

      const form = generateForm(projectData.value, projectModuleData.value);  // 将项目数据和模块数据传递给 generateForm
      console.log('生成的form数据:', form);  // 打印 form 数据，调试查看其结构

      // 生成文档时使用动态 form 数据
      const url = await createDoc({
        imgUrl: generateAndDownloadImage(),
        form: form,
        projectModuleData: projectModuleData.value,  // 确保传递了 projectModuleData
      });

      if (url) {
        const res = await fetch(url);
        const blob = await res.blob();

        uploadFileToOss(blob, 1).then((filename) => {
          if (filename) {
            getSignedUrl(filename).then((signedUrl) => {
              fileUrl.value = signedUrl;
              officeEmbedUrl.value = `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(signedUrl)}`;
              isDocumentGenerated.value = true;
              isLoading.value = false; // 加载结束
            });
          }
        });
      } else {
        isLoading.value = false; // 加载结束
      }
    };

    // 刷新文档
    async function updateDocumentAfterEdit() {
      isLoading.value = true; // 开始加载
      if (!isDocumentGenerated.value && !uploadedFileUrl.value) {
        ElMessage.error('请先进行评估报告生成');
        isLoading.value = false; // 加载结束
        return;
      }

      try {
        const urlToFetch = uploadedFileUrl.value || fileUrl.value;
        const res = await fetch(urlToFetch);
        if (!res.ok) {
          throw new Error(`Failed to fetch the document: ${res.status} ${res.statusText}`);
        }

        const blob = await res.blob();
        const version = 2;

        const filename = await uploadFileToOss(blob, version);

        if (filename) {
          const signedUrl = await getSignedUrl(filename);
          fileUrl.value = signedUrl;
          officeEmbedUrl.value = `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(signedUrl)}`;
        } else {
          console.error("文件上传失败，未获得文件名");
        }
      } catch (error) {
        console.error("更新文档时发生错误:", error);
      } finally {
        isLoading.value = false; // 加载结束
      }
    }

   // 上传新文件
async function handleUploadNewFile() {
  if (!isDocumentGenerated.value) {
    ElMessage.error('请先进行评估报告生成');
    return;
  }

  // 获取文件输入框
  const inputFile = document.querySelector('.file-input');
  if (!inputFile) {
    console.error("找不到文件输入框！");
    return;
  }

  // 触发文件选择框
  inputFile.click();  // 触发文件选择框的弹出
}

// 处理文件上传事件
function handleFileChange(event) {
  const file = event.target.files ? event.target.files[0] : null; // 检查是否有文件
  if (file) {
    if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
      const reader = new FileReader();
      reader.onload = (e) => {
        // 使用 Blob 包装 ArrayBuffer
        const blob = new Blob([e.target.result]);
        
        uploadFileToOss(blob, 1).then((filename) => {
          if (filename) {
            uploadedFileName.value = file.name; // 更新文件名
            uploadedFileUrl.value = `https://your-oss-url/${filename}`; // 替换为您的 OSS URL
            getSignedUrl(filename).then((signedUrl) => {
              fileUrl.value = signedUrl;
              officeEmbedUrl.value = `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(signedUrl)}`;
              isDocumentGenerated.value = true;  // 设置文档生成标志为 true
            });
          }
        });
      };
      reader.readAsArrayBuffer(file);  // 读取文件为 ArrayBuffer
    } else {
      ElMessage.error('请上传有效的 DOCX 文件');
    }
  } else {
    ElMessage.error('请先选择一个文件');
  }
}


async function handleSubmit() {
  if (!isDocumentGenerated.value && !uploadedFileUrl.value) {
    ElMessage.error('请先生成评估报告');
    return;
  }

  const urlToSubmit = uploadedFileUrl.value || fileUrl.value;
  const projectId = selectedProjectId.value;  // 获取选中的 projectId

  if (!projectId) {
    ElMessage.error('请选择一个项目');
    return;
  }

  // 提交文件 URL 和 projectId 到后端
  try {
    const response = await axios.post('http://localhost:9000/project/submitDocument', {
      fileUrl: urlToSubmit,
      projectId: projectId  // 传递 projectId
    });

    console.log("url测试：" + urlToSubmit);

    if (response.data === 'Document URL updated successfully.') {
      ElMessage.success('文件提交成功');
    } else {
      ElMessage.error('文件提交失败: ' + response.data);
    }
  } catch (error) {
    console.error('提交文件时发生错误:', error);
    ElMessage.error('提交文件时发生错误');
  }
}


    // 生成并下载图像
    function generateAndDownloadImage() {
      const canvas = document.createElement('canvas');
      canvas.width = 800;
      canvas.height = 500;
      const context = canvas.getContext('2d');

      context.fillStyle = '#f9f9f9';
      context.fillRect(0, 0, canvas.width, canvas.height);

      context.strokeStyle = '#000';
      context.lineWidth = 5;
      context.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);

      context.fillStyle = '#4a4a4a';
      context.font = 'bold 36px Arial';
      context.textAlign = 'center';
      context.fillText('评估机构资质证书', canvas.width / 2, 60);

      context.font = '24px Arial';
      context.fillStyle = '#333';
      context.textAlign = 'left';
      context.fillText('认证机构：算道软件评估平台', 50, 120);
      context.fillText('证书编号：123456789', 50, 160);
      context.fillText('评估项目：软件开发成本评估', 50, 200);
      context.fillText('评估日期：2024年11月19日', 50, 240);
      context.fillText('签名：____________________', 50, 300);
      context.fillText('机构负责人：张三', 50, 340);
      context.fillText('认证有效期至：2025年11月19日', 50, 380);

      context.globalAlpha = 0.1;
      context.font = 'bold 100px Arial';
      context.fillStyle = '#bbb';
      context.textAlign = 'center';
      context.fillText('CERTIFIED', canvas.width / 2, canvas.height / 2);

      return canvas.toDataURL('image/png');
    }

    return {
      fileUrl,
      officeEmbedUrl,
      previewHeight,
      isDocumentGenerated,
      handleClick,
      updateDocumentAfterEdit,
      handleUploadNewFile,
      handleSubmit,
      handleFileChange,
      isLoading,
      uploadedFileName,
      auditStatus,
      auditOpinion,
      fetchAuditOpinion,
      projects,
      selectedProjectId,
      onProjectChange,
      fetchAuditStatusAndOpinion,
      fetchProjectDetails,
      fetchProjectModules
    };
  },
});
</script>

<style lang="scss" scoped>
.page-container {
  width: 100%;
  height: fit-content;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 21px;
  box-sizing: border-box;
}
.project-select {
  margin-left: 10px; /* 给下拉框添加与按钮间的间距 */
  width: 200px; /* 可以根据需要调整宽度 */
}

/* 标题和按钮容器 */
.header-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  background-color: white;
  padding: 10px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  margin-bottom: 10px;
}

.title-container {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-left: 10px;
}

.title {
  font-size: 24px;
  font-weight: bold;
  margin-left: 0;
}

.title-icon {
  width: 30px;
  height: 30px;
  object-fit: cover;
}

.button-container {
  display: flex;
  gap: 10px;
  justify-content: flex-start;
}

.preview-and-notice-container {
  display: flex;
  width: 100%;
  gap: 15px;
}

.preview-container {
  width: 70%;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.notice-container {
  width: 30%;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  padding: 15px;
}

.notice-container h3 {
  margin-top: 0;
}

.notice-container ul {
  list-style-type: disc;
  padding-left: 20px;
}

.generate-btn {
  margin-right: 10px;
}

.file-input {
  display: none;
}

.doc-preview {
  width: 100%;
  height: 100%;
  border: none;
}

.preview-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  font-size: 25px;
  color: #888;
  padding: 20px;
  height: 100%;
}

.highlight {
  color: red;
}

.upload-btn {
  margin-left: 10px;
}

.submit-btn {
  margin-left: 10px;
}
.uploaded-file-name {
  margin-left: 10px;
  text-decoration: underline;
  color: blue;
}
.loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(255, 255, 255, 0.7); /* 半透明背景 */
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999; /* 确保在最上层 */
}

.spinner {
  border: 8px solid rgba(0, 0, 0, 0.1); /* 背景色 */
  border-left-color: #3498db; /* 动画色 */
  border-radius: 50%;
  width: 50px;
  height: 50px;
  animation: spin 1s linear infinite; /* 旋转动画 */
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
.audit-status-container {
  margin-top: 20px;
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.audit-status {
  display: inline-block;
  padding: 10px 20px;
  border-radius: 50px;
  font-size: 18px;
  font-weight: bold;
  color: #fff;
  text-align: center;
  line-height: 40px;
  position: relative;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* 阴影效果 */
  transition: transform 0.2s ease-in-out; /* 放大动画 */
}

.audit-status.failed {
  background-color: #e74c3c; /* 红色，未通过 */
}

.audit-status.passed {
  background-color: #2ecc71; /* 绿色，已通过 */
}

.audit-status.loading {
  background-color: #f39c12; /* 黄色，加载中 */
}

.audit-status .status-text {
  position: relative;
  z-index: 1;
}

.audit-status:hover {
  transform: scale(1.1); /* 放大效果 */
}
.audit-opinion-container {
  margin-top: 20px;
}

.audit-opinion-wrapper {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.audit-opinion-text {
  border: 1px solid #dcdfe6;
  padding: 10px;
  border-radius: 4px;
  flex-grow: 1;
}

.refresh-btn {
  margin-left: 10px;
}

</style>
