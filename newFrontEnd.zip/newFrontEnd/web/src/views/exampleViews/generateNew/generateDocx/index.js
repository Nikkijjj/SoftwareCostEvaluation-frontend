import { saveAs } from 'file-saver';
import { generateDocxFile } from './common';
import templateFile from './template.docx?url';

/**
 *
 * 创建一个文档文件
 */
export async function createDoc(option) {
    let imgUrl = option.imgUrl;
    let form = option.form;
    /** 获取二进制字符串 */
    let templateFile_ = await fetch(templateFile).then((_) => _.blob());
    let projectModuleData = option.projectModuleData;  // 获取模块数据
    console.log("我在generateDoc获取", JSON.stringify(projectModuleData, null, 2));

    // 确保 projectModuleData 是数组，避免 undefined
    if (Array.isArray(projectModuleData) && projectModuleData.length > 0) {
        // 将 projectModuleData 转化为一个格式化的字符串（例如，列表格式）
        form.modules = projectModuleData.map(module => {
            return `${module.module_name}: ${module.module_desc}`;
        }).join('\n');  // 将每个模块信息以换行符连接成一个字符串
    } else {
        form.modules = ''; // 如果没有模块数据，设置为空字符串
    }
    console.log("填充的数据:", form.modules);

    let out = await generateDocxFile(templateFile_, {
        ...form,
        image: imgUrl,
    }).catch((e) => {
        console.error('文档生成失败:', e);
        return '';
    });

    if (!out) {
        return;
    }

    // 创建一个临时的文件 URL
    const fileUrl = URL.createObjectURL(out);
    
    // 返回文件的 URL
    return fileUrl;
}
