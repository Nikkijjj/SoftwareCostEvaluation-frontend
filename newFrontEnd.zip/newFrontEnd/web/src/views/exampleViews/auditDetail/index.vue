<template>
  <DefinScrollbar height="100%" :showUpBt="true">
    <div class="all-container">
      <div class="page-container">
        <p class="title">报告审核</p>
        <div class="preview-container">
          <VueOfficeDocx class="doc-preview" :src="abc" />
        </div>
        <div class="audit-container">
          <el-input
            type="textarea"
            :rows="4"
            placeholder="请输入审核意见"
            v-model="auditSuggest"
          ></el-input>
        </div>
        <div class="audit-buttons">
          <el-button @click="audit(1)" type="primary">审核通过</el-button>
          <el-button @click="audit(0)" type="primary">审核不通过</el-button>
        </div>
      </div>

      <!-- 右侧容器，显示项目信息和注意事项 -->
      <div class="other-container">
        <div class="project-info" v-if="project">
          <p class="title">项目信息</p>
          <div class="project-item">
            <strong>项目ID:</strong> {{ project.project_id }}
          </div>
          <div class="project-item">
            <strong>项目名称:</strong> {{ project.project_name }}
          </div>
          <div class="project-item">
            <strong>公司:</strong> {{ project.company }}
          </div>
          <div class="project-item">
            <strong>截止日期:</strong> {{ project.ddl }}
          </div>
          <div class="project-item">
            <strong>开始日期:</strong> {{ project.begin }}
          </div>
        </div>

        <p class="title">注意事项</p>
        <p class="notice-text">
          请查看报告内容，并作出评价，写下意见，并确定审核是否通过！
        </p>
      </div>
    </div>
  </DefinScrollbar>
</template>

<script>
import { defineComponent, ref, onMounted } from 'vue';
import VueOfficeDocx from '@vue-office/docx';
import '@vue-office/docx/lib/index.css';
import axios from 'axios';
import { useRouter, useRoute } from 'vue-router';
import { ElMessage } from 'element-plus';
axios.defaults.withCredentials = true;

export default defineComponent({
  components: {
    VueOfficeDocx
  },
  setup() {
    const router = useRouter();
    let id = ref('');
    let project = ref({
      project_id: '',
      project_name: '',
      begin: '',
      ddl: '',
      company: '',
      url: ''
    });
    const abc = "https://doc-storage.oss-cn-beijing.aliyuncs.com/generated/doc-v1.docx?OSSAccessKeyId=LTAI5tSEWCtbQnf9DqmoApY5&Expires=1734673651&Signature=7vZSkZMYF4dUTqBRtPa3OLDzqD0%3D";
    const auditSuggest = ref(null);

    async function load() {
      axios.get('http://localhost:9000/project/getall', {
        params: {
          projectId: id.value
        }
      }).then(res => {
        if (res.data.isOk) {
          project.value.project_id = res.data.project.project_id;
          project.value.project_name = res.data.project.project_name;
          project.value.company = res.data.project.company;
          project.value.begin = res.data.project.begin;
          project.value.ddl = res.data.project.ddl;
          project.value.url = res.data.project.url;
          console.log('加载成功' + res.data.project.project_name);
        } else {
          console.log("错误");
        }
      });
    }

    function audit(i) {
      const requestData = {
        project_id: id.value,
        auditStatus: i,
        auditSuggest: auditSuggest.value,
      };

      console.log('Project ID:', id.value);
      console.log('Audit Suggest:', auditSuggest.value);

      axios.post('http://localhost:9000/project/audit', requestData)
        .then(res => {
          console.log(res.data);  // 打印完整的响应
          if (res.data.isOk) {
            ElMessage.success('审核成功！'); // 审核成功提示
            // 你可以在这里添加更多的逻辑，比如重定向到其他页面
          } else {
            ElMessage.error('错误: ' + res.data.message); // 假设返回的错误信息在 `message` 字段
          }
        })
        .catch(error => {
          console.error('请求失败:', error);
          ElMessage.error('请求失败，请稍后再试'); // 请求失败的提示
        });
    }

    onMounted(() => {
      const route = useRoute();
      id.value = route.query.id;
      console.log(id.value);
      load();
    });

    return {
      project,
      id,
      auditSuggest,
      abc,
      audit
    };
  }
});
</script>

<style lang="scss" scoped>
.all-container {
  display: flex;
  flex-direction: row;
  height: 100vh;
  padding: 20px 30px;
  box-sizing: border-box;
  gap: 30px;
}

.page-container {
  background: white;
  border-radius: 8px;
  width: 65%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 20px;
  box-sizing: border-box;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.other-container {
  background: #f9f9f9; /* 背景颜色 */
  border-radius: 8px;
  width: 30%;
  height: 100%;
  padding: 20px;
  box-sizing: border-box;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  overflow-y: auto;
}

.title {
  font-size: 24px;
  margin-bottom: 10px;
  color: #333;
}

.project-info {
  margin-bottom: 20px;
}

.project-item {
  padding: 10px;
  margin: 5px 0;
  background: #ffffff; /* 每个信息项的背景 */
  border-radius: 4px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.notice-text {
  margin-top: 10px;
  padding: 10px;
  background-color: #fff4e2; /* 注释框背景颜色 */
  border: 1px solid #ffa500; /*  注释框边框颜色 */
  border-radius: 4px;
}

.preview-container {
  display: flex;
  justify-content: center;
  width: 100%;
  height: 500px;
  border: 1px solid #ccc;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(26, 173, 70, 0.1);
  margin-bottom: 20px;
  overflow: scroll;
}

.doc-preview {
  width: 100%;
  height: auto;
  min-height: 100%;
  object-fit: contain;
  border-radius: 8px;
}

.audit-container {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}

.audit-buttons {
  display: flex;
  justify-content: space-between;
}
</style>
