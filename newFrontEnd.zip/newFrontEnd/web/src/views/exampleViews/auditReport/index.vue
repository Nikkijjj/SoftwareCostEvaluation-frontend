<template>
    <div class="page-container main-view">
        <div class="table-box content-container page-content-box">
            <div class="top-container">
                
               
            </div>
            <div class="table-container">
                <el-table :data="projects" key="project_id" width="100%" height="100%" border>
                    <el-table-column property="project_id" label="项目账号" width="150"></el-table-column>
                    <el-table-column property="project_name" label="项目名称" width="240"></el-table-column>
                    <!-- <el-table-column property="project_info" label="项目信息" width="240"></el-table-column> -->
                    <el-table-column property="company" label="公司" width="160"></el-table-column>
                    <el-table-column property="begin" label="开始时间" width="160"></el-table-column>
                    <el-table-column property="ddl" label="结束时间" width="160"></el-table-column>
                    <el-table-column property="auditStatus" label="审核状态" width="240">
                        <template #default="{ row }">
                        <span v-if="row.auditStatus == 0">审核未过</span>
                        <span v-else-if="row.auditStatus == 1">审核已通过</span>
                        <span v-else="row.auditStatus === null || row.auditStatus === undefined || row.auditStatus !== 0 && row.auditStatus !== 1">未审核</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="操作" width="200">
                        <template #default="{ row }">
                        <!-- 根据审核状态决定按钮是否可用 -->
                        <el-button
                            :type="row.auditStatus == 1 ? 'success' : 'danger'"
                            size="small"
                            :disabled="row.auditStatus == 1"
                            @click="audit(row.project_id)"
                        >
                            <span v-if="row.auditStatus == 0">审核</span>
                            <span v-else-if="row.auditStatus == 1">已审核</span>
                        </el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
            <div class="pagination-container">
                
            </div>
        </div>
        <EditDataDialog ref="EditDataDialogRef"></EditDataDialog>
    </div>
</template>

<script>
/**
 * 页面例子
 */ 
import {
    defineComponent,
    onBeforeUnmount,
    ref,
    reactive,
    getCurrentInstance,
    onActivated,
} from 'vue';
import axios from 'axios';
    axios.defaults.withCredentials = true;
    import { onMounted } from 'vue';
    import {RouterLink,RouterView,useRouter, useRoute,viewDepthKey} from 'vue-router'

export default defineComponent({
    components: {
     
    },
    setup() {
        function Project(project_id, project_name, project_info, begin, ddl, company, status, auditStatus, auditSuggest, step, ufp_num, dfp_num, s_num, ei_num, eo_num, eq_num, ilf_num, elf_num) {
            this.project_id = project_id;
            this.project_name = project_name;
            this.project_info = project_info;
            this.begin = begin;
            this.ddl = ddl;
            this.company = company;
            this.status = status;
            this.auditStatus = auditStatus;
            this.auditSuggest = auditSuggest;
            this.step = step;
            this.ufp_num = ufp_num;
            this.dfp_num = dfp_num;
            this.s_num = s_num;
            this.ei_num = ei_num;
            this.eo_num = eo_num;
            this.eq_num = eq_num;
            this.ilf_num = ilf_num;
            this.elf_num = elf_num;
            }
        let projects =ref([]);
        const router = useRouter();    
        let time = ref('');    
        time.value=new Date;

        function audit(id){
            console.log('123:'+id)
            router.push({ name: 'audit-detail', query: { id: id } });
        //    router.push({ name: 'audit-detail',params: { 'id': id } });
        }

        const load=async()=>{
		console.log('加载');
		axios.post('http://localhost:9000/project/selectAllProjects').then(res=>{
							if(res.data.isOK){
                                console.log("输出没啊？？？？")
                                console.log(time.value.toLocaleString());
                                console.log(res.data.projects);
								projects.value.push(...res.data.projects);
                                console.log("hhhhhhhhh"+projects.value);
							}
						})
	};
    onMounted(() => {
      console.log('组件已挂载');
      load();
    })
        return {
            time,
          projects,
          audit
        };
    },
    
});
</script>

<style lang="scss" scoped>
.main-view {
    display: flex;
    flex-direction: column;
    
    > .page-query-box {
        margin: 0 0 10px 0 !important;
        padding: 10px 10px 0px 10px;
        :deep(.el-form-item) {
            margin-bottom: 10px !important;
        }
        :deep(.el-form-item--default) {
            width: 100%;
            margin-right: 0;
        }
    }
    
    > .content-container {
        flex: 1;
        display: flex;
        flex-direction: column;
        padding: 10px 10px;
        box-sizing: border-box;
        background: #fff;
        
        > .top-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 0px 0 10px 0;
            font-size: 20px; /* Increase font size here for top-container */
        }

        > .table-container {
            flex: 1 1 auto;
            height: 0;
            overflow: auto;
        }
    }
    
    .pagination-container {
        display: flex;
        justify-content: flex-end;
        padding: 0;
        margin: 10px 0 0 0;
        font-size: 20px; /* Increase font size here for pagination */
    }
}

/* You can increase the font size for table header and rows as well */
.el-table th {
    font-size: 20px; /* Increase font size for table headers */
}

.el-table td {
    font-size: 20px; /* Increase font size for table cells */
}

.el-button {
    font-size: 14px; /* Increase font size for button text */
}

.el-table-column {
    font-size: 20px; /* Increase font size for column text */
}

</style>
