<template>
  <div class="page-container">
    <!-- 加边框的区域 -->
    <div class="content-wrapper">
      <!-- 卡片容器 -->
      <el-row :gutter="20" class="card-container">
        <el-col :span="8" v-for="(item, index) in dataContainer.list" :key="index">
          <el-card shadow="hover" class="project-card">
            <div class="card-content">
              <!-- 项目名称 -->
              <h3 class="project-name">{{ item.project_name }}</h3>
              <!-- 截止时间 -->
              <p class="project-info">
                <strong>截止时间:</strong> {{ item.ddl }}
              </p>
              <!-- 公司 -->
              <p class="project-info">
                <strong>所属公司:</strong> {{ item.company }}
              </p>
              <!-- 状态 -->
              <p class="project-info">
                <strong>评估状态:</strong>
                <el-tag :type="item.status === '已评估' ? 'success' : item.status === '进行中' ? 'primary' : 'danger'">
                  {{ item.status }}
                </el-tag>
              </p>
            </div>
            <!-- 操作按钮 -->
            <div class="card-actions">
              <el-button type="primary" size="small" @click="handleDetails(item)">项目详情</el-button>
              <el-button type="success" size="small" @click="handleEdit(item)">进入评估</el-button>
              <el-dropdown>
                <el-button type="info" size="small">
                  查看结果
                  <el-icon class="el-icon--right">
                    <arrow-down />
                  </el-icon>
                </el-button>
                <template #dropdown>
                  <el-dropdown-menu>
                    <el-dropdown-item @click="handleResulta(item)">评估进度看板</el-dropdown-item>
                    <el-dropdown-item @click="handleResultb(item)">评估结果看板</el-dropdown-item>
                    <el-dropdown-item @click="handleResultc(item)">任务分配看板</el-dropdown-item>
                  </el-dropdown-menu>
                </template>
              </el-dropdown>
            </div>
          </el-card>
        </el-col>
      </el-row>
      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination v-show="true" :total="dataContainer.config.total" :background="true"
          :current-page="dataContainer.params.pageNum" :page-size="dataContainer.params.pageSize"
          layout="total, sizes, prev, pager, next, jumper" :page-sizes="[10, 20, 30, 50]" :pager-count="7" @size-change="(size) => {
              dataContainer.params.pageSize = size;
              getDataList();
            }
            " @current-change="(page) => {
                dataContainer.params.pageNum = page;
                getDataList();
              }
              " />
      </div>
    </div>
  </div>
</template>


<script>
/**
 * 页面例子
 */
import {
  defineComponent,
  ref,
  reactive,
} from 'vue';
import { useRouter } from 'vue-router';
import { copyValue } from '@/common/otherTools';
import DictTags from '@/components/dictTags.vue';
import { debounceFn } from '@/common/debounceAndThrottle';
import { messageSuccess } from '@/action/messagePrompt.js';
import SvgIcon from '@/components/svgIcon/index.vue';
import { hasPermi } from '@/action/powerTools';
import axios from 'axios';


export default defineComponent({
  components: {
    DictTags,
    SvgIcon,
  },
  setup() {
    const router = useRouter();
    const searchKeyword = ref('');
    const searchKeystatus = ref('');
    const searchdate = ref('');
    const selectedDate = ref('');
    const dataContainer = reactive({
      loading: false,
      showSearch: true,
      checked__: false, //是否全选
      form: {},
      params: {
        //基础参数
        pageNum: 1,
        pageSize: 10,
      },
      config: {
        total: 0,
      },
      list: [], //当前展示的数据列表
      currentRows: [], //当前多选的数据列表
      optionList: [
        { value: 1, label: '未评估', elTagType: 'danger' },
        { value: 2, label: '已评估', elTagType: 'success' },
        { value: 3, label: '进行中', elTagType: 'warning' },
      ],
    });
    /** 获取数据列表 */
    const getDataList = debounceFn(function () {
      if (dataContainer.loading) return;
      dataContainer.loading = true;

      fetch('http://localhost:9000/project/selectAllProjects')
        .then(response => response.json())
        .then(res => {
          dataContainer.list = res.projects || [];
          dataContainer.config.total = res.total;
          /** 默认不选择 */
          dataContainer.list.forEach((item) => {
            item.checked__ = false;
          });
          dataContainer.checked__ = false;
        })
        .catch(error => {
          console.error('Error fetching data:', error);
        })
        .finally(() => {
          dataContainer.loading = false;
        });
    }, 70);
    getDataList();
    /** 双击单元格，复制单元格内容 */
    function handleCopyVale(_, __, ___, event) {
      copyValue(event.target.innerText);
      messageSuccess('复制成功，内容为：' + event.target.innerText);
    }
    /** 排序触发事件 */
    function handleSortChange(column, prop, order) {
      dataContainer.form.orderByColumn = column.prop;
      dataContainer.form.isAsc = column.order;
      getDataList();
    }


    const searchProgBN = () => {
      const projectName = searchKeyword.value;
      if (projectName) {
        axios.post('http://localhost:9000/project/selectProjectsByNameshr', { project_name: projectName })
          .then(response => {
            console.log('Response:', response.data);
            // 在这里处理响应数据
            const res = response.data;
            dataContainer.list = res.projects || [];
            dataContainer.config.total = res.total;
            /** 默认不选择 */
            dataContainer.list.forEach((item) => {
              item.checked__ = false;
            });
            dataContainer.checked__ = false;
          })
          .catch(error => {
            console.error('Error:', error);
            // 在这里处理错误
          });
      } else {
        console.warn('Project name is empty');
      }
    }

    const searchProgStatus = () => {
      const ProjectStatus = searchKeystatus.value;
      let statusString;

      switch (ProjectStatus) {
        case 1:
          statusString = "未评估";
          break;
        case 2:
          statusString = "已评估";
          break;
        case 3:
          statusString = "进行中";
          break;
        default:
          console.warn('Invalid project status');
          return; // 退出函数，不发送请求
      }
      axios.post('http://localhost:9000/project/selectProjectsByStatusshr', { status: statusString })
        .then(response => {
          console.log('Response:', response.data);
          // 在这里处理响应数据
          const res = response.data;
          dataContainer.list = res.projects || [];
          dataContainer.config.total = res.total;
          /** 默认不选择 */
          dataContainer.list.forEach((item) => {
            item.checked__ = false;
          });
          dataContainer.checked__ = false;
        })
        .catch(error => {
          console.error('Error:', error);
          // 在这里处理错误
        });
    }


    const handleDateChange = () => {
      const selectDate = searchdate.value;

      const utcDate = new Date(selectDate);
      // Beijing time is UTC+8
      const offset = 8 * 60; // 8 hours in minutes
      const localDate = new Date(utcDate.getTime() + offset * 60 * 1000);

      // Format the date to only include year, month, and day
      const year = localDate.getFullYear();
      const month = String(localDate.getMonth() + 1).padStart(2, '0'); // Months are zero-based
      const day = String(localDate.getDate()).padStart(2, '0');

      const beijingTime = `${year}-${month}-${day}`;

      axios.post('http://localhost:9000/project/selectProjectsByDDLshr', { ddl: beijingTime })
        .then(response => {
          console.log('Response:', response.data);
          // 在这里处理响应数据
          const res = response.data;
          dataContainer.list = res.projects || [];
          dataContainer.config.total = res.total;
          /** 默认不选择 */
          dataContainer.list.forEach((item) => {
            item.checked__ = false;
          });
          dataContainer.checked__ = false;
        })
        .catch(error => {
          console.error('Error:', error);
          // 在这里处理错误
        });

    }

    /** 搜索按钮操作 */
    function handleQuery() {
      dataContainer.params.pageNum = 1;
      getDataList();
    }
    /** 重置按钮操作 */
    function resetQuery() {
      dataContainer.form = {};
      handleQuery();
    }

    /** 项目详情按钮操作 */
    function handleDetails(row, querys) {
      if (row.project_id) {
        localStorage.setItem('project_id', row.project_id);
      }
      router.push({
        name: 'project-detail',
        params: {
          sign: row.project_id,
        },
        querys,
      });
    }
    /** 项目评估结果按钮操作 */
    function handleResulta(row, querys) {
      if (row.project_id) {
        localStorage.setItem('project_id', row.project_id);
      }
      router.push({
        name: 'big-screen-show_4',//结果展示一
        params: {
          sign: row.project_id,
        },
        querys,
      });
    }

    function handleResultb(row, querys) {
      if (row.project_id) {
        localStorage.setItem('project_id', row.project_id);
      }
      router.push({
        name: 'big-screen-show_3',//结果展示二
        params: {
          sign: row.project_id,
        },
        querys,
      });
    }

    function handleResultc(row, querys) {
      if (row.project_id) {
        localStorage.setItem('project_id', row.project_id);
      }
      router.push({
        name: 'big-screen-show_2',//结果展示三
        params: {
          sign: row.project_id,
        },
        querys,
      });
    }


    /** 编辑按钮操作 */
    function handleEdit(row, querys) {
      router.push({
        name: 'show-list-update',
        params: {
          sign: row.id || new Date().getTime(),
        },
        querys,
      });
    }

    return {
      dataContainer,
      getDataList,
      handleCopyVale,
      handleSortChange,
      handleQuery,
      resetQuery,
      handleDetails,
      handleEdit,
      hasPermi,
      searchKeyword,
      searchProgBN,
      searchKeystatus,
      searchProgStatus,
      searchdate,
      handleDateChange,
      selectedDate,
      handleResulta,
      handleResultb,
      handleResultc
    };
  },
});
</script>

<style lang="scss" scoped>
.main-view {
  display: flex;
  flex-direction: column;
  /** 页面间隔css变量，可自行调节 */
  --view-gap: 10px;

  >.page-query-box {
    margin: 0 0 var(--view-gap) 0 !important;
    padding: var(--view-gap) var(--view-gap) 0px var(--view-gap);

    :deep(.el-form-item) {
      margin-bottom: var(--view-gap) !important;
    }

    :deep(.el-form-item--default) {
      width: 100%;
      margin-right: 0;
    }
  }

  >.content-container {
    flex: 1;
    display: flex;
    flex-direction: column;
    padding: var(--view-gap) var(--view-gap);
    box-sizing: border-box;
    background: #fff;

    >.top-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 0px 0 var(--view-gap) 0;

      >.left {
        display: flex;
        flex-direction: row;
        align-items: center;

        >* {
          margin: 0 var(--view-gap) 0 0 !important;
        }
      }

      >.right {
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: flex-end;

        >* {
          margin: 0 0px 0 var(--view-gap) !important;
        }
      }
    }

    >.table-container {
      flex: 1 1 auto;
      height: 0;
      overflow: auto;
    }
  }

  .pagination-container {
    display: flex;
    justify-content: flex-end;
    padding: 0;
    margin: var(--view-gap) 0 0 0;
  }
}

.page-container {
  padding: 20px;
  /* 内部间距 */
  background-color: #ebeaea;
  /* 背景颜色 */
  width: 95%;
  /* 宽度设为95%，占满父容器的95% */
  height: 600px;
  /* 固定高度 */
  border: 1px solid #dcdcdc1d;
  /* 边框颜色 */
  margin: 20px auto;
  /* 上下左右都有20px的外边距，并且水平居中 */
  border-radius: 10px;
  /* 圆角效果 */
}

.card-container {
  margin-top: 20px;
}

.card-wrapper {
  background-color: #ffffff;
  /* 背景框的颜色 */
  padding: 20px;
  border-radius: 10px;
  /* 圆角效果 */
  border: 1px solid #e8e8e84b;
  /* 边框颜色 */
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
  /* 阴影效果 */
}

.project-card {
  border: 1px solid #e8e8e8;
  border-radius: 10px;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
  /* 给卡片添加阴影 */
  transition: all 0.3s ease;
}

.project-card:hover {
  box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
  /* 增加悬浮时的阴影 */
  transform: translateY(-5px);
  /* 悬浮效果 */
}

.card-content {
  margin-bottom: 15px;
}

.project-name {
  font-size: 20px;
  font-weight: bold;
  color: #333;
  margin-bottom: 10px;
}

.project-info {
  font-size: 16px;
  color: #666;
  margin-bottom: 5px;
  line-height: 3;
  /* 增加每行文字的间距 */
}

.card-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
}

.card-actions el-button {
  margin-right: 10px;
}

.el-button {
  border-radius: 6px;
  /* 按钮圆角 */
}

.pagination-container {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
</style>