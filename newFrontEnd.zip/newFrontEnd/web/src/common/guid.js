/**
 * 前端生成唯一标识 (guid)
 */
import { nanoid } from 'nanoid';

export function getNanoid() {
    return nanoid();
}
